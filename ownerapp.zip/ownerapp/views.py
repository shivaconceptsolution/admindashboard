from django.shortcuts import render,redirect
from .models import Loginbank
from empapp.models import Reg
def index(request):
	if request.method=="POST":
		s = Loginbank.objects.filter(userid=request.POST['txtuser'],passfield=request.POST['txtpass'])
		if(s.count()>0):
			return redirect('odash')

	return render(request,"ownerapp/index.html")


def odash(request):
	return render(request,"ownerapp/odash.html",{'r':Reg.objects.all()})
def approve(request):
    status = request.GET["q"]
    id = request.GET["id"]
    r= Reg.objects.get(pk=id)
    r.status=status
    r.save()
    return redirect('odash')
