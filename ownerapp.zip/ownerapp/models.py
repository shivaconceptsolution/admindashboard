from django.db import models

class Loginbank(models.Model):
	userid = models.CharField(max_length=10)
	passfield = models.CharField(max_length=10)
	def __str__(self):
		return "userid is "+self.userid + "password is "+self.passfield


