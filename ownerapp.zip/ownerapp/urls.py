from django.urls import path
from . import views

urlpatterns = [

path('',views.index,name='index'),
path('ownerdash',views.odash,name='odash'),
path('approve',views.approve,name='approve')

]