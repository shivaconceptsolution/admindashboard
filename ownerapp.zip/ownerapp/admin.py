from django.contrib import admin
from .models import Loginbank
admin.site.register(Loginbank)

# Register your models here.
