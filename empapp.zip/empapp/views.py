from django.shortcuts import render
from django.http import HttpResponse
from .models import Reg
def index(request):
	if request.method=="POST":
		s=''
		res = Reg.objects.filter(email=request.POST["txtemail"],password=request.POST["txtpass"]).values_list('status', flat=True)
		if res.count()>0:
			if res[0]=='0':
			 return HttpResponse("You are blocked by admin contact to re-process ")
			else:
			  return HttpResponse('login success')
		else:
			return HttpResponse('Invalid userid and password')    		
	return render(request,"empapp/login.html")
